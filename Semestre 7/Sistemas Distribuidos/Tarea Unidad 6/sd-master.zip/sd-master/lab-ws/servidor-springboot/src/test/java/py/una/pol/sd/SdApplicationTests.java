package py.una.pol.sd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdApplicationTests {

	@Test
	void contextLoads() {
	}

}

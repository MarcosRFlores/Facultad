Requisitos:
- python3

- Pip3

pip3 install requests


Existe un archivo de configuración "ConfigFile.properties"